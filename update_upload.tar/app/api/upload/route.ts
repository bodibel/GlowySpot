import { NextRequest, NextResponse } from "next/server";
import { mkdir } from "fs/promises";
import { join } from "path";
import sharp from "sharp";
import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const file = formData.get("file") as File;

        if (!file) {
            return NextResponse.json({ error: "No file received." }, { status: 400 });
        }

        const buffer = Buffer.from(await file.arrayBuffer());

        // --- 1. AI Content Moderation with Gemini ---
        if (!process.env.GEMINI_API_KEY) {
            console.warn("GEMINI_API_KEY is missing, skipping AI moderation (fail-open).");
        } else {
            try {
                // Configure safety settings to be VERY strict
                const model = genAI.getGenerativeModel({
                    model: "gemini-2.0-flash", // Use 2.0 Flash as it's the latest stable and has good vision
                    safetySettings: [
                        {
                            category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
                            threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                        },
                        {
                            category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                            threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                        },
                        {
                            category: HarmCategory.HARM_CATEGORY_HARASSMENT,
                            threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                        },
                        {
                            category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                            threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
                        },
                    ],
                });

                const prompt = `Analyze this image for a beauty-related social media platform. 
                Respond ONLY with a JSON object in this format:
                {
                  "isSafe": boolean, 
                  "isBeautyRelated": boolean,
                  "reason": "Hungarian explanation if rejected, otherwise empty string"
                }
                Rejection criteria: 
                - isSafe = false if: Porn, Hentai, Gore, Violence, Illegal content, Nudity (even if non-pornographic nudity), or strong sexual poses.
                - isBeautyRelated = false if: Irrelevant content (e.g., cars, empty landscapes, animals, unrelated objects).
                Note: Close-up skin, hair, nails, hands, and feet ARE beauty-related and SAFE.`;

                const result = await model.generateContent([
                    prompt,
                    {
                        inlineData: {
                            data: buffer.toString("base64"),
                            mimeType: file.type
                        }
                    }
                ]);

                // Check if the response was blocked by safety filters
                if (result.response.candidates?.[0]?.finishReason === "SAFETY") {
                    return NextResponse.json(
                        { error: "A kép szexuális vagy nem biztonságos tartalmat hordoz, ezért elutasítva." },
                        { status: 400 }
                    );
                }

                const responseText = result.response.text();
                // Clean markdown JSON blocks if present
                const cleanedJson = responseText.replace(/```json/g, "").replace(/```/g, "").trim();
                const analysis = JSON.parse(cleanedJson);

                if (!analysis.isSafe) {
                    return NextResponse.json(
                        { error: analysis.reason || "A kép nem megengedett tartalmat hordoz." },
                        { status: 400 }
                    );
                }

                if (!analysis.isBeautyRelated) {
                    return NextResponse.json(
                        { error: analysis.reason || "A kép nem illik a szépségápolás témakörébe (pl. autó, tájkép, stb.)." },
                        { status: 400 }
                    );
                }
            } catch (aiError: any) {
                console.error("Gemini AI Check failed (Rate Limit / Network Error):", aiError);
                // Fail-open: if moderation fails due to rate limits or timeout, we allow the upload so users aren't blocked.
                console.warn("Skipping moderation due to API error (Fail-Open).");
            }
        }

        // --- 2. Convert to WebP & Save ---
        const relativeUploadDir = "/uploads";
        const uploadDir = join(process.cwd(), "public", relativeUploadDir);

        try {
            await mkdir(uploadDir, { recursive: true });
        } catch (e) {
            // ignore check
        }

        // Generate filename
        const timestamp = Date.now();
        const originalName = file.name.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9.-]/g, "");
        const filename = `${timestamp}-${originalName}.webp`;
        const filepath = join(uploadDir, filename);

        // Convert and Save
        await sharp(buffer)
            .webp({ quality: 80 })
            .toFile(filepath);

        const fileUrl = `${relativeUploadDir}/${filename}`;

        return NextResponse.json({ url: fileUrl });
    } catch (error) {
        console.error("Error uploading file:", error);
        return NextResponse.json(
            { error: "Rendszerhiba a feltöltés során." },
            { status: 500 }
        );
    }
}
